package pl.gclicker.listener.punch;

import java.awt.AWTException;
import java.awt.Robot;

import pl.gclicker.gui.ClickerGui;

public class Punch {
    public Punch() {
        Punch.Start();
    }

    public static /* synthetic */ void Start() {
    	try {
    		Robot robot = new Robot();
            String slotPunch = ClickerGui.slotPunch.getText().toUpperCase();
            for (int i = 0; i < slotPunch.length(); ++i) {
                char lol = slotPunch.charAt(i);
                robot.keyPress(lol);
                robot.keyRelease(lol);
            }
            Thread.sleep(10);
            robot.keyPress(17);
            Thread.sleep(1);
            robot.mousePress(4);
            Thread.sleep(152);
            robot.mouseRelease(4);
            robot.keyPress(83);
            robot.keyRelease(83);
            Thread.sleep(1);
            robot.keyRelease(17);
            String slotMiecz = ClickerGui.slotMiecz.getText().toUpperCase();
            for (int i = 0; i < slotMiecz.length(); ++i) {
                char lol = slotMiecz.charAt(i);
                robot.keyPress(lol);
                robot.keyRelease(lol);
            }
    	} catch(AWTException e) {
    		e.printStackTrace();
    	} catch (InterruptedException e) {
			e.printStackTrace();
		}
    }
}