package pl.gclicker.listener.wedka;

import java.awt.AWTException;
import java.awt.Robot;

import pl.gclicker.gui.ClickerGui;

public class Wedka {
    public Wedka() {
        Wedka.Start();
    }

    public static /* synthetic */ void Start() {
    	try {
    		Robot robot = new Robot();
            String slotPunch = ClickerGui.slotWedka.getText().toUpperCase();
            for (int i = 0; i < slotPunch.length(); ++i) {
                char lol = slotPunch.charAt(i);
                robot.keyPress(lol);
                robot.keyRelease(lol);
            }
            robot.mousePress(4);
            robot.mouseRelease(4);
            Thread.sleep(123);
            String slotMiecz = ClickerGui.slotMiecz.getText().toUpperCase();
            for (int i = 0; i < slotMiecz.length(); ++i) {
                char lol = slotMiecz.charAt(i);
                robot.keyPress(lol);
                robot.keyRelease(lol);
            }
    	} catch(AWTException e) {
    		e.printStackTrace();
    	} catch (InterruptedException e) {
			e.printStackTrace();
		}
    }
}