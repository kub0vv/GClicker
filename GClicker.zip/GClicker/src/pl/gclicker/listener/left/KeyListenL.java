/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.jnativehook.keyboard.NativeKeyEvent
 *  org.jnativehook.keyboard.NativeKeyListener
 */
package pl.gclicker.listener.left;

import java.awt.Color;
import java.util.ArrayList;

import com.github.kwhat.jnativehook.keyboard.NativeKeyEvent;
import com.github.kwhat.jnativehook.keyboard.NativeKeyListener;

import pl.gclicker.Main;
import pl.gclicker.gui.ClickerGui;
import pl.gclicker.gui.StatusGui;

public class KeyListenL
implements NativeKeyListener {
    private /* synthetic */ ArrayList<Integer> pressed;
    public static /* synthetic */ ArrayList<Integer> localKeyCode;
    public static /* synthetic */ boolean usingMouseToggle;
    public static /* synthetic */ Integer toggleKeyCode;
    public static volatile /* synthetic */ boolean toggled;

    static /* synthetic */ {
        usingMouseToggle = false;
        toggled = false;
    }

    public /* synthetic */ KeyListenL() {
        this.pressed = new ArrayList();
        localKeyCode = new ArrayList();
    }

    public /* synthetic */ void nativeKeyPressed(NativeKeyEvent e) {
        this.pressed.add(e.getKeyCode());
        if (Main.keyListenL && e.getKeyCode() != 29 && e.getKeyCode() != 42 && e.getKeyCode() != 3675) {
            usingMouseToggle = false;
            localKeyCode = new ArrayList();
            for (int i = 0; i < this.pressed.size(); ++i) {
                localKeyCode.add(this.pressed.get(i));
            }
            String setText = "Aktywowanie (";
            if (localKeyCode.size() == 1) {
                setText = String.valueOf(setText) + NativeKeyEvent.getKeyText((int)localKeyCode.get(0)) + ")";
            } else {
                for (int i = 0; i < localKeyCode.size() - 1; ++i) {
                    setText = String.valueOf(setText) + NativeKeyEvent.getKeyText((int)localKeyCode.get(i)) + "+";
                }
                setText = String.valueOf(setText) + NativeKeyEvent.getKeyText((int)localKeyCode.get(localKeyCode.size() - 1)) + "]";
            }
            toggleKeyCode = (int)localKeyCode.get(0);
            ClickerGui.btnAktywowanief_1.setText(setText);
            Main.keyListenL = false;
        } else if (this.pressed.contains(toggleKeyCode) && !Main.keyListenL && !usingMouseToggle ) {
            boolean bl = toggled = !toggled;
            if (toggled) {
                ClickerGui.MacroL.setText("true");
                ClickerGui.MacroL.setForeground(Color.GREEN);
                StatusGui.frame.repaint();
                StatusGui.macroLeftEnabled.setText("Lewy Clicker: ON");
                StatusGui.macroLeftEnabled.setForeground(Color.GREEN);
            } else {
                ClickerGui.MacroL.setText("false");
                ClickerGui.MacroL.setForeground(Color.RED);
                StatusGui.frame.repaint();
                StatusGui.macroLeftEnabled.setText("Lewy Clicker: OFF");
                StatusGui.macroLeftEnabled.setForeground(Color.RED);
            }
        }
    }

    public /* synthetic */ void nativeKeyReleased(NativeKeyEvent e) {
        this.pressed = new ArrayList();
    }

    public /* synthetic */ void nativeKeyTyped(NativeKeyEvent e) {
    }
}

