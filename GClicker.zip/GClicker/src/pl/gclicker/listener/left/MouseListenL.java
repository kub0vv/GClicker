/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.jnativehook.mouse.NativeMouseEvent
 *  org.jnativehook.mouse.NativeMouseInputListener
 */
package pl.gclicker.listener.left;

import java.awt.Color;
import java.util.ArrayList;

import com.github.kwhat.jnativehook.mouse.NativeMouseEvent;
import com.github.kwhat.jnativehook.mouse.NativeMouseInputListener;

import pl.gclicker.Main;
import pl.gclicker.gui.ClickerGui;
import pl.gclicker.gui.StatusGui;

public class MouseListenL
implements NativeMouseInputListener {
    public volatile /* synthetic */ ClickerL c;
    public /* synthetic */ ArrayList<Integer> localToggleKey;

    public /* synthetic */ MouseListenL() {
        this.localToggleKey = new ArrayList();
    }

    public /* synthetic */ void nativeMouseClicked(NativeMouseEvent arg0) {
    }

    public /* synthetic */ void nativeMousePressed(NativeMouseEvent arg0) {
        if (arg0.getButton() == 3) {
            ClickerL.run = false;
            ClickerL.ignore = false;
        }
        if (Main.keyListenL && !ClickerL.ignore && arg0.getButton() != 1 && arg0.getButton() != 2) {
            KeyListenL.usingMouseToggle = true;
            this.localToggleKey = new ArrayList();
            this.localToggleKey.add(arg0.getButton());
            ClickerGui.btnAktywowanief_1.setText("[" + NativeMouseEvent.getModifiersText((int)this.localToggleKey.get(0)) + "]");
        } else if (KeyListenL.usingMouseToggle) {
            if (arg0.getButton() == KeyListenL.toggleKeyCode.intValue()) {
                boolean bl = KeyListenL.toggled = !KeyListenL.toggled;
                if (KeyListenL.toggled) {
                    ClickerGui.MacroL.setText("true");
                    ClickerGui.MacroL.setForeground(Color.GREEN);
                    StatusGui.frame.repaint();
                    StatusGui.macroLeftEnabled.setText("Lewy Clicker: ON");
                    StatusGui.macroLeftEnabled.setForeground(Color.GREEN);
                } else {
                    ClickerGui.MacroL.setText("false");
                    ClickerGui.MacroL.setForeground(Color.RED);
                    StatusGui.frame.repaint();
                    StatusGui.macroLeftEnabled.setText("Lewy Clicker: OFF");
                    StatusGui.macroLeftEnabled.setForeground(Color.RED);
                }
            }
        } else if (KeyListenL.toggled && arg0.getButton() == 1) {
            ClickerL.run = true;
            ClickerL.lastTime = System.currentTimeMillis();
            this.c = new ClickerL();
        }
    }

    public /* synthetic */ void nativeMouseReleased(NativeMouseEvent arg0) {
        if (arg0.getButton() == 1) {
            if (!ClickerL.ignore) {
                ClickerL.mineFirst = false;
                ClickerL.run = false;
            } else {
                ClickerL.ignore = false;
            }
        }
    }

    public /* synthetic */ void nativeMouseDragged(NativeMouseEvent e) {
    }

    public /* synthetic */ void nativeMouseMoved(NativeMouseEvent arg0) {
    }
}

