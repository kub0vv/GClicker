package pl.gclicker.listener.zmianaseta;

import java.awt.Color;

import com.github.kwhat.jnativehook.keyboard.NativeKeyEvent;
import com.github.kwhat.jnativehook.keyboard.NativeKeyListener;

import pl.gclicker.Main;
import pl.gclicker.gui.ClickerGui;

public class ZmianaSetaListenBind
implements NativeKeyListener {
    public static /* synthetic */ Integer toggleKeyCode;

    public /* synthetic */ void nativeKeyPressed(NativeKeyEvent e) {
        if (Main.zmianaSetaListen && e.getKeyCode() != 29 && e.getKeyCode() != 42 && e.getKeyCode() != 3675) {
            String setText = "Aktywowanie (";
            setText = String.valueOf(setText) + NativeKeyEvent.getKeyText((int)e.getKeyCode()) + ")";
            toggleKeyCode = e.getKeyCode();
            ClickerGui.buttonZmianaSeta.setText(setText);
            Main.zmianaSetaListen = false;
        } else if (e.getKeyCode() == toggleKeyCode.intValue()) {
        	ZmianaSeta.Start();
        }
    }

    public /* synthetic */ void nativeKeyReleased(NativeKeyEvent e) {
    }

    public /* synthetic */ void nativeKeyTyped(NativeKeyEvent e) {
    }
}
