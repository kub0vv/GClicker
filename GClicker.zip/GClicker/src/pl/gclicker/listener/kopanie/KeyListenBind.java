package pl.gclicker.listener.kopanie;

import java.awt.Color;

import com.github.kwhat.jnativehook.keyboard.NativeKeyEvent;
import com.github.kwhat.jnativehook.keyboard.NativeKeyListener;

import pl.gclicker.Main;
import pl.gclicker.gui.ClickerGui;
import pl.gclicker.gui.StatusGui;

public class KeyListenBind
implements NativeKeyListener {
    public static /* synthetic */ Integer toggleKeyCode;
    public static volatile /* synthetic */ boolean toggled;

    static /* synthetic */ {
        toggled = false;
    }

    public /* synthetic */ void nativeKeyPressed(NativeKeyEvent e) {
        if (Main.keyListenBind && e.getKeyCode() != 29 && e.getKeyCode() != 42 && e.getKeyCode() != 3675) {
            String setText = "Aktywowanie (";
            setText = String.valueOf(setText) + NativeKeyEvent.getKeyText((int)e.getKeyCode()) + ")";
            toggleKeyCode = e.getKeyCode();
            ClickerGui.buttonAktywacja.setText(setText);
            Main.keyListenBind = false;
        } else if (e.getKeyCode() == toggleKeyCode.intValue()) {
            boolean bl = toggled = !toggled;
            if (toggled) {
            	ClickerGui.textAktywacja.setText("true");
                ClickerGui.textAktywacja.setForeground(Color.GREEN);
                StatusGui.frame.repaint();
                StatusGui.kopanieEnabled.setText("Kopanie: ON");
                StatusGui.kopanieEnabled.setForeground(Color.GREEN);
                new Kopanie();
            } else {
            	ClickerGui.textAktywacja.setText("false");
            	ClickerGui.textAktywacja.setForeground(Color.RED);
                StatusGui.frame.repaint();
            	StatusGui.kopanieEnabled.setText("Kopanie: OFF");
            	StatusGui.kopanieEnabled.setForeground(Color.RED);
                Kopanie.Stop();
            }
        }
    }

    public /* synthetic */ void nativeKeyReleased(NativeKeyEvent e) {
    }

    public /* synthetic */ void nativeKeyTyped(NativeKeyEvent e) {
    }
}

