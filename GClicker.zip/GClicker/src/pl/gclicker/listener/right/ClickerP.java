/*
 * Decompiled with CFR 0.150.
 */
package pl.gclicker.listener.right;

import java.awt.AWTException;
import java.awt.Robot;

import pl.gclicker.Main;

public class ClickerP {
    public static /* synthetic */ boolean run;
    private static /* synthetic */ Robot robot;
    public static /* synthetic */ boolean ignore;
    private static /* synthetic */ int delay;
    public static /* synthetic */ long lastTime;

    static /* synthetic */ {
        run = false;
        ignore = false;
        delay = -1;
        lastTime = 0L;
    }

    public /* synthetic */ ClickerP() {
        try {
            robot = new Robot();
        }
        catch (AWTException e) {
            e.printStackTrace();
        }
    }

    public static /* synthetic */ void Clicker() {
        try {
            while (true) {
                Thread.sleep(1L);
                if (delay == -1) {
                    delay = 1000 / Main.ms + 1;
                }
                if (!run || !KeyListenP.toggled || System.currentTimeMillis() - lastTime < (long)delay) continue;
                ignore = true;
                if (!Main.Pignore) {
                    robot.mousePress(4);
                }
                lastTime = System.currentTimeMillis();
                delay = 1000 / Main.ms + 1;
            }
        }
        catch (InterruptedException e) {
            e.printStackTrace();
            return;
        }
    }
}

