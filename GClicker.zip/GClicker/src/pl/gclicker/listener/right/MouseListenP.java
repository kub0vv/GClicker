/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.jnativehook.mouse.NativeMouseEvent
 *  org.jnativehook.mouse.NativeMouseInputListener
 */
package pl.gclicker.listener.right;

import java.awt.Color;
import java.util.ArrayList;

import com.github.kwhat.jnativehook.mouse.NativeMouseEvent;
import com.github.kwhat.jnativehook.mouse.NativeMouseInputListener;

import pl.gclicker.Main;
import pl.gclicker.gui.ClickerGui;
import pl.gclicker.gui.StatusGui;
import pl.gclicker.listener.left.ClickerL;

public class MouseListenP
implements NativeMouseInputListener {
    public volatile /* synthetic */ ClickerP c;
    public /* synthetic */ ArrayList<Integer> localToggleKey;

    public /* synthetic */ MouseListenP() {
        this.localToggleKey = new ArrayList();
    }

    public /* synthetic */ void nativeMouseClicked(NativeMouseEvent arg0) {
    }

    public /* synthetic */ void nativeMousePressed(NativeMouseEvent arg0) {
        if (arg0.getButton() == 3) {
            ClickerP.run = false;
            ClickerP.ignore = false;
        }
        if (Main.keyListenP && !ClickerP.ignore && arg0.getButton() != 1 && arg0.getButton() != 2) {
            KeyListenP.usingMouseToggle = true;
            this.localToggleKey = new ArrayList();
            this.localToggleKey.add(arg0.getButton());
            ClickerGui.btnAktywowanief_1.setText("[" + NativeMouseEvent.getModifiersText((int)this.localToggleKey.get(0)) + "]");
        } else if (KeyListenP.usingMouseToggle) {
            if (arg0.getButton() == KeyListenP.toggleKeyCode.intValue()) {
                boolean bl = KeyListenP.toggled = !KeyListenP.toggled;
                if (KeyListenP.toggled) {
                    ClickerGui.MacroP.setText("true");
                    ClickerGui.MacroP.setForeground(Color.GREEN);
                    StatusGui.frame.repaint();
                    StatusGui.macroRightEnabled.setText("Prawy Clicker: ON");
                    StatusGui.macroRightEnabled.setForeground(Color.GREEN);
                } else {
                    ClickerGui.MacroP.setText("false");
                    ClickerGui.MacroP.setForeground(Color.RED);
                    StatusGui.frame.repaint();
                    StatusGui.macroRightEnabled.setText("Prawy Clicker: OFF");
                    StatusGui.macroRightEnabled.setForeground(Color.RED);
                }
            }
        } else if (!ClickerP.ignore && KeyListenP.toggled && arg0.getButton() == 2) {
            ClickerP.run = true;
            ClickerP.lastTime = System.currentTimeMillis();
            this.c = new ClickerP();
        }
    }

    public /* synthetic */ void nativeMouseReleased(NativeMouseEvent arg0) {
        if (arg0.getButton() == 2) {
            Main.Pignore = false;
            ClickerP.run = false;
            if (!ClickerP.ignore) {
                Main.Pignore = false;
                ClickerP.run = false;
            } else {
                ClickerP.ignore = false;
                ClickerL.ignore = true;
            }
        }
    }

    public /* synthetic */ void nativeMouseDragged(NativeMouseEvent arg0) {
    }

    public /* synthetic */ void nativeMouseMoved(NativeMouseEvent arg0) {
    }
}

