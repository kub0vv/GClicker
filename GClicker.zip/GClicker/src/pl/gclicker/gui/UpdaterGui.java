package pl.gclicker.gui;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import pl.gclicker.updater.Updater;

public class UpdaterGui extends JFrame {
	public static JFrame frame = new JFrame();
	public static JButton update;
	
	public static void start() {	
		ImageIcon image = new ImageIcon("logo.png");

		JPanel panel = new JPanel();
		frame.setTitle("GClicker (Updater)");
		frame.setSize(300, 150);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.setVisible(true);
		frame.add(panel);
		
		panel.setLayout(null);
		panel.setBounds(0, 0, 300, 100);
		
		JLabel success = new JLabel("Znaleziono aktualizacje! Kliknij przycisk!");
		success.setForeground(Color.GREEN);
		success.setBounds(25, 0, 300, 50);
		panel.add(success);
		
		JLabel offclickerInfo = new JLabel("Clicker si� wy��czy po zaktualizowaniu!");
		offclickerInfo.setForeground(Color.RED);
		offclickerInfo.setBounds(25, 20, 300, 50);
		panel.add(offclickerInfo);
		
		update = new JButton("Aktualizuj teraz!");
		update.setForeground(Color.WHITE);
		update.setBackground(new Color(113, 0, 253));
		update.setBounds(50, 55, 175, 25);
		update.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Updater.download();
			}
		});
		panel.add(update);
		
		frame.setIconImage(image.getImage());
		panel.setBackground(new Color(0x000000));
	}
}
