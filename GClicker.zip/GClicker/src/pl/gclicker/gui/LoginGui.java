package pl.gclicker.gui;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class LoginGui extends JFrame implements ActionListener {
	private static JLabel userLabel;
	private static JTextField userText;
	private static JButton button;
	private static JLabel success;
	private static JFrame frame = new JFrame();
	
	public static void start() {
		ImageIcon image = new ImageIcon("logo.png");

		JPanel panel = new JPanel();
		frame.setTitle("GClicker (Auth)");
		frame.setSize(300, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.setVisible(true);
		frame.add(panel);
		
		panel.setLayout(null);
		
		userLabel = new JLabel("Twoja licencja: ");
		userLabel.setForeground(Color.WHITE);
		userLabel.setBounds(10, 20, 100, 25);
		panel.add(userLabel);
		
		userText = new JTextField(20);
		userText.setBounds(100, 20, 165, 25);
		panel.add(userText);
				
		button = new JButton("Zaloguj!");
		button.setBounds(90, 80, 80, 25);
		button.setBackground(new Color(0, 0, 0));
		button.setForeground(Color.WHITE);
		button.setBorder(BorderFactory.createLineBorder(new Color(113, 0, 253), 3));
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				button.setBackground(new Color(113, 0, 253));
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				button.setBackground(new Color(0,0,0));
			}
		});
		button.addActionListener(new LoginGui());
		panel.add(button);
		
		success = new JLabel("");
		success.setBounds(10, 110, 300, 25);
		success.setForeground(Color.RED);
		panel.add(success);
		
		frame.setIconImage(image.getImage());
		panel.setBackground(new Color(0x000000));
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		try {
            String inputLine;
            URL website = new URL("https://gclicker.pl/api/license.php?license=" + userText.getText());
            URLConnection connection = website.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            while ((inputLine = in.readLine()) != null) {
                if (inputLine.equals("true")) {
                	LoginGui.frame.dispose();
                	ClickerGui.start();
                	StatusGui.start();
                	continue;
                } else {
                    String inputLine1;
                    URL website1 = new URL("https://gclicker.pl/api/time.php?license=" + userText.getText());
                    URLConnection connection1 = website1.openConnection();
                    BufferedReader in1 = new BufferedReader(new InputStreamReader(connection1.getInputStream()));
                    while ((inputLine1 = in1.readLine()) != null) {
                    	if(inputLine1.equals("true")) {
                        	LoginGui.frame.dispose();
                        	ClickerGui.start();
                        	StatusGui.start();
                        	continue;
                    	} else {
                    		success.setText("Podana licencja jest nieprawidlowa!");
                    		success.setForeground(Color.RED);
                    	}
                    }
                }
            }
            return;
        }
        catch (MalformedURLException e1) {
        	e1.printStackTrace();
        }
        catch (IOException e2) {
        	e2.printStackTrace();
        }
	}
}
