package pl.gclicker.gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import pl.gclicker.Main;

public class ClickerGui extends JFrame implements ActionListener {
 	private static JButton macroButton;
	private static JButton klepaButton;
	private static JButton kopanieButton;
	private static JButton dodatkiButton;
	private static JButton opcjeButton;
	private static JLabel logoText;
	public static JFrame frame = new JFrame();
	private static JPanel macroTab;
	private static JPanel klepaTab;
	private static JPanel kopanieTab;
	private static JPanel dodatkiTab;
	private static JPanel opcjeTab;
	private static JPanel tabs;
	public static JSlider cpsMinSlider;
	public static JSlider cpsMaxSlider;
	public static JSlider ppmSlider;
	public static JLabel lpmMinValue;
	public static JLabel lpmMaxValue;
	public static JLabel ppmValue;
    public static JLabel MacroP;
    public static JLabel MacroL;
    public static JLabel wywalanie;
    public static JButton btnAktywowanief;
    public static JButton btnAktywowanief_1;
    public static /* synthetic */ JPanel contentPane;
    public static /* synthetic */ JLabel textAktywacja;
    public static /* synthetic */ JButton buttonAktywacja;
    public static /* synthetic */ JTextField stoniarkaSize;
    public static JTextField stoniarkaUp;
    public static /* synthetic */ JTextField komenda;
    public static /* synthetic */ JTextField slotsZloto;
    public static /* synthetic */ JTextField turJedzenie;
    public static /* synthetic */ JTextField turRepairKilof;
    public static /* synthetic */ JTextField slotJedzenie;
    public static /* synthetic */ JTextField slotKilof;
    public static /* synthetic */ JRadioButton aktywacjaRepairCommand;
    public static /* synthetic */ JRadioButton radioButton_2;
    public static JRadioButton autogardaLpm;
    public static JButton buttonZmianaSeta;
    public static JButton buttonPunchowanie;
    public static JButton buttonSniezka;
    public static JButton buttonPerla;
    public static JButton buttonWedka;
    public static JTextField slotPunch;
    public static JTextField slotMiecz;
    public static JTextField slotPerla;
    public static JTextField slotSniezka;
    public static JTextField slotWedka;
    public static JButton buttonWywalanie;
	
	public static void start() {
		ImageIcon image = null;
		try {
			image = new ImageIcon(new URL("https://cdn.discordapp.com/attachments/937751850017517618/975058656951431178/gclicker_logo.png"));
		} catch (MalformedURLException e1) {
			e1.printStackTrace();
		}

		JPanel panel = new JPanel();
		
		macroTab = new JPanel();
		JLabel macroText = new JLabel("Macro");
		macroText.setBounds(0, 10, 150, 50);
		macroText.setFont(new Font("Segoe UI", Font.BOLD, 30));
		macroText.setForeground(Color.WHITE);
		macroTab.add(macroText);
		
		JLabel lpmText = new JLabel("Lewy przycisk myszy LPM:");
		lpmText.setBounds(0, 35, 200, 50);
		lpmText.setFont(new Font("Segoe UI", Font.BOLD, 16));
		lpmText.setForeground(Color.WHITE);
		macroTab.add(lpmText);
		
		lpmMinValue = new JLabel("9 MIN CPS");
		lpmMinValue.setBounds(160, 65, 200, 50);
		lpmMinValue.setFont(new Font("Segoe UI", Font.BOLD, 16));
		lpmMinValue.setForeground(Color.WHITE);
		macroTab.add(lpmMinValue);
		
		lpmMaxValue = new JLabel("15 MAX CPS");
		lpmMaxValue.setBounds(160, 105, 200, 50);
		lpmMaxValue.setFont(new Font("Segoe UI", Font.BOLD, 16));
		lpmMaxValue.setForeground(Color.WHITE);
		macroTab.add(lpmMaxValue);
		
		cpsMinSlider = new JSlider(6, 20, 9);
		cpsMinSlider.setBounds(0, 80, 150, 25);
		cpsMinSlider.setBackground(new Color(0x000000));
		cpsMinSlider.addChangeListener(new ChangeListener() {
			
			@Override
			public void stateChanged(ChangeEvent e) {
				lpmMinValue.setText(String.valueOf(cpsMinSlider.getValue() + " MIN CPS"));
				Main.minCPS = Integer.valueOf(cpsMinSlider.getValue());
				if(cpsMinSlider.getValue() > cpsMaxSlider.getValue()) {
					cpsMaxSlider.setValue(Integer.valueOf(cpsMinSlider.getValue()));
				}
			}
		});
		macroTab.add(cpsMinSlider);
		
		cpsMaxSlider = new JSlider(6, 20, 15);
		cpsMaxSlider.setBounds(0, 120, 150, 25);
		cpsMaxSlider.setBackground(new Color(0x000000));
		cpsMaxSlider.addChangeListener(new ChangeListener() {
			
			@Override
			public void stateChanged(ChangeEvent e) {
				lpmMaxValue.setText(String.valueOf(cpsMaxSlider.getValue() + " MAX CPS"));
				Main.maxCPS = Integer.valueOf(cpsMaxSlider.getValue());
				if(cpsMaxSlider.getValue() < cpsMinSlider.getValue()) {
					cpsMinSlider.setValue(Integer.valueOf(cpsMaxSlider.getValue()));
				}
			}
		});
		macroTab.add(cpsMaxSlider);
		
        btnAktywowanief_1 = new JButton("Aktywowanie (F4)");
        btnAktywowanief_1.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent arg0) {
                if (!Main.keyListenL) {
                    btnAktywowanief_1.setText("Kliknij dowolny przycisk!");
                    Main.keyListenL = true;
                }
            }
        });
        btnAktywowanief_1.setBounds(0, 160, 233, 23);
        btnAktywowanief_1.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnAktywowanief_1.setBackground(new Color(0, 0, 0));
        btnAktywowanief_1.setForeground(Color.WHITE);
        btnAktywowanief_1.setBorder(BorderFactory.createLineBorder(new Color(113, 0, 253), 3));
        btnAktywowanief_1.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent evt) {
				btnAktywowanief_1.setBackground(new Color(113, 0, 253));
			}
			
			public void mouseExited(MouseEvent evt) {
				btnAktywowanief_1.setBackground(new Color(0,0,0));
			}
		});
        macroTab.add(btnAktywowanief_1);
        
        autogardaLpm = new JRadioButton();
        autogardaLpm.setBounds(245, 160, 20, 20);
        autogardaLpm.setFont(new Font("Segoe UI", Font.BOLD, 14));
        autogardaLpm.setBackground(new Color(0, 0, 0));
        autogardaLpm.setForeground(Color.WHITE);
        macroTab.add(autogardaLpm);
                
        JLabel autogardaText = new JLabel("AutoGarda (Niebawem!)");
        autogardaText.setBounds(270, 145, 250, 50);
        autogardaText.setFont(new Font("Segoe UI", Font.BOLD, 14));
        autogardaText.setForeground(Color.WHITE);
		macroTab.add(autogardaText);
        
        MacroL = new JLabel("false");
        MacroL.setForeground(Color.RED);
        MacroL.setBounds(210, 50, 44, 21);
        MacroL.setFont(new Font("Segoe UI", Font.BOLD, 16));
        macroTab.add(MacroL);
        
		JLabel ppmText = new JLabel("Prawy przycisk myszy PPM:");
		ppmText.setBounds(0, 175, 250, 50);
		ppmText.setFont(new Font("Segoe UI", Font.BOLD, 16));
		ppmText.setForeground(Color.WHITE);
		macroTab.add(ppmText);
		
        btnAktywowanief = new JButton("Aktywowanie (F4)");
        btnAktywowanief.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent arg0) {
                if (!Main.keyListenP) {
                    btnAktywowanief.setText("Kliknij dowolny przycisk!");
                    Main.keyListenP = true;
                }
            }
        });
        btnAktywowanief.setBounds(0, 290, 233, 23);
        btnAktywowanief.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnAktywowanief.setBackground(new Color(0, 0, 0));
        btnAktywowanief.setForeground(Color.WHITE);
        btnAktywowanief.setBorder(BorderFactory.createLineBorder(new Color(113, 0, 253), 3));
        btnAktywowanief.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent evt) {
				btnAktywowanief.setBackground(new Color(113, 0, 253));
			}
			
			public void mouseExited(MouseEvent evt) {
				btnAktywowanief.setBackground(new Color(0,0,0));
			}
		});
        macroTab.add(btnAktywowanief);
        
		ppmValue = new JLabel("20 CPS");
		ppmValue.setBounds(160, 200, 200, 50);
		ppmValue.setFont(new Font("Segoe UI", Font.BOLD, 16));
		ppmValue.setForeground(Color.WHITE);
		macroTab.add(ppmValue);
		
		ppmSlider = new JSlider(6, 50, 20);
		ppmSlider.setBounds(0, 215, 150, 25);
		ppmSlider.setBackground(new Color(0x000000));
		ppmSlider.addChangeListener(new ChangeListener() {
			
			@Override
			public void stateChanged(ChangeEvent e) {
				ppmValue.setText(String.valueOf(ppmSlider.getValue() + " CPS"));
				Main.ms = Integer.valueOf(ppmSlider.getValue());
			}
		});
		macroTab.add(ppmSlider);
		
        MacroP = new JLabel("false");
        MacroP.setForeground(Color.RED);
        MacroP.setBounds(210, 190, 44, 21);
        MacroP.setFont(new Font("Segoe UI", Font.BOLD, 16));
        macroTab.add(MacroP);
		
		/*                                                    */
		
		klepaTab = new JPanel();
		JLabel klepaText = new JLabel("Klepa");
		klepaText.setBounds(0, 10, 150, 50);
		klepaText.setFont(new Font("Segoe UI", Font.BOLD, 30));
		klepaText.setForeground(Color.WHITE);
		klepaTab.add(klepaText);
		
		JLabel zmianaSetaText = new JLabel("Zmiana seta (1080p):");
		zmianaSetaText.setBounds(0, 35, 200, 50);
		zmianaSetaText.setFont(new Font("Segoe UI", Font.BOLD, 16));
		zmianaSetaText.setForeground(Color.WHITE);
		klepaTab.add(zmianaSetaText);
		
		buttonZmianaSeta = new JButton("Aktywowanie (F4)");
		buttonZmianaSeta.addActionListener(new ActionListener(){

            @Override
            public /* synthetic */ void actionPerformed(ActionEvent arg0) {
                if (!Main.zmianaSetaListen) {
                	buttonZmianaSeta.setText("Kliknij dowolny przycisk!");
                    Main.zmianaSetaListen = true;
                }
            }
        });
		buttonZmianaSeta.setBounds(0, 75, 233, 23);
		buttonZmianaSeta.setFont(new Font("Segoe UI", Font.BOLD, 14));
		buttonZmianaSeta.setBackground(new Color(0, 0, 0));
		buttonZmianaSeta.setForeground(Color.WHITE);
		buttonZmianaSeta.setBorder(BorderFactory.createLineBorder(new Color(113, 0, 253), 3));
		buttonZmianaSeta.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent evt) {
				buttonZmianaSeta.setBackground(new Color(113, 0, 253));
			}
			
			public void mouseExited(MouseEvent evt) {
				buttonZmianaSeta.setBackground(new Color(0,0,0));
			}
		});
        klepaTab.add(buttonZmianaSeta);
		
		JLabel punchText = new JLabel("Punchowanie:");
		punchText.setBounds(0, 90, 200, 50);
		punchText.setFont(new Font("Segoe UI", Font.BOLD, 16));
		punchText.setForeground(Color.WHITE);
		klepaTab.add(punchText);
		
		buttonPunchowanie = new JButton("Aktywowanie (F4)");
		buttonPunchowanie.addActionListener(new ActionListener(){

            @Override
            public /* synthetic */ void actionPerformed(ActionEvent arg0) {
                if (!Main.punchListen) {
                	buttonPunchowanie.setText("Kliknij dowolny przycisk!");
                    Main.punchListen = true;
                }
            }
        });
		buttonPunchowanie.setBounds(0, 130, 233, 23);
		buttonPunchowanie.setFont(new Font("Segoe UI", Font.BOLD, 14));
		buttonPunchowanie.setBackground(new Color(0, 0, 0));
		buttonPunchowanie.setForeground(Color.WHITE);
		buttonPunchowanie.setBorder(BorderFactory.createLineBorder(new Color(113, 0, 253), 3));
		buttonPunchowanie.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent evt) {
				buttonPunchowanie.setBackground(new Color(113, 0, 253));
			}
			
			public void mouseExited(MouseEvent evt) {
				buttonPunchowanie.setBackground(new Color(0,0,0));
			}
		});
        klepaTab.add(buttonPunchowanie);
        
        JLabel sniezkaText = new JLabel("Bind sniezki:");
        sniezkaText.setBounds(0, 155, 200, 50);
        sniezkaText.setFont(new Font("Segoe UI", Font.BOLD, 16));
        sniezkaText.setForeground(Color.WHITE);
		klepaTab.add(sniezkaText);
		
		buttonSniezka = new JButton("Aktywowanie (F4)");
		buttonSniezka.addActionListener(new ActionListener(){

            @Override
            public /* synthetic */ void actionPerformed(ActionEvent arg0) {
                if (!Main.sniezkaListen) {
                	buttonSniezka.setText("Kliknij dowolny przycisk!");
                    Main.sniezkaListen = true;
                }
            }
        });
		buttonSniezka.setBounds(0, 195, 233, 23);
		buttonSniezka.setFont(new Font("Segoe UI", Font.BOLD, 14));
		buttonSniezka.setBackground(new Color(0, 0, 0));
		buttonSniezka.setForeground(Color.WHITE);
		buttonSniezka.setBorder(BorderFactory.createLineBorder(new Color(113, 0, 253), 3));
		buttonSniezka.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent evt) {
				buttonSniezka.setBackground(new Color(113, 0, 253));
			}
			
			public void mouseExited(MouseEvent evt) {
				buttonSniezka.setBackground(new Color(0,0,0));
			}
		});
        klepaTab.add(buttonSniezka);
        
        JLabel perlaText = new JLabel("Bind perly:");
        perlaText.setBounds(0, 220, 200, 50);
        perlaText.setFont(new Font("Segoe UI", Font.BOLD, 16));
        perlaText.setForeground(Color.WHITE);
		klepaTab.add(perlaText);
		
		buttonPerla = new JButton("Aktywowanie (F4)");
		buttonPerla.addActionListener(new ActionListener(){

            @Override
            public /* synthetic */ void actionPerformed(ActionEvent arg0) {
                if (!Main.perlaListen) {
                	buttonPerla.setText("Kliknij dowolny przycisk!");
                    Main.perlaListen = true;
                }
            }
        });
		buttonPerla.setBounds(0, 260, 233, 23);
		buttonPerla.setFont(new Font("Segoe UI", Font.BOLD, 14));
		buttonPerla.setBackground(new Color(0, 0, 0));
		buttonPerla.setForeground(Color.WHITE);
		buttonPerla.setBorder(BorderFactory.createLineBorder(new Color(113, 0, 253), 3));
		buttonPerla.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent evt) {
				buttonPerla.setBackground(new Color(113, 0, 253));
			}
			
			public void mouseExited(MouseEvent evt) {
				buttonPerla.setBackground(new Color(0,0,0));
			}
		});
        klepaTab.add(buttonPerla);
        
        JLabel wedkaText = new JLabel("Bind Wedki:");
        wedkaText.setBounds(0, 285, 200, 50);
        wedkaText.setFont(new Font("Segoe UI", Font.BOLD, 16));
        wedkaText.setForeground(Color.WHITE);
		klepaTab.add(wedkaText);
		
		buttonWedka = new JButton("Aktywowanie (F4)");
		buttonWedka.addActionListener(new ActionListener(){

            @Override
            public /* synthetic */ void actionPerformed(ActionEvent arg0) {
                if (!Main.wedkaListen) {
                	buttonWedka.setText("Kliknij dowolny przycisk!");
                    Main.wedkaListen = true;
                }
            }
        });
		buttonWedka.setBounds(0, 325, 233, 23);
		buttonWedka.setFont(new Font("Segoe UI", Font.BOLD, 14));
		buttonWedka.setBackground(new Color(0, 0, 0));
		buttonWedka.setForeground(Color.WHITE);
		buttonWedka.setBorder(BorderFactory.createLineBorder(new Color(113, 0, 253), 3));
		buttonWedka.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent evt) {
				buttonWedka.setBackground(new Color(113, 0, 253));
			}
			
			public void mouseExited(MouseEvent evt) {
				buttonWedka.setBackground(new Color(0,0,0));
			}
		});
        klepaTab.add(buttonWedka);

		/*                                                      */
		
		kopanieTab = new JPanel();
		JLabel kopanieText = new JLabel("Kopanie");
		kopanieText.setBounds(0, 10, 150, 50);
		kopanieText.setFont(new Font("Segoe UI", Font.BOLD, 30));
		kopanieText.setForeground(Color.WHITE);
		kopanieTab.add(kopanieText);
		
        buttonAktywacja = new JButton("Aktywowanie (F4)");
        buttonAktywacja.addActionListener(new ActionListener(){

            @Override
            public /* synthetic */ void actionPerformed(ActionEvent arg0) {
                if (!Main.keyListenBind) {
                    buttonAktywacja.setText("Kliknij dowolny przycisk!");
                    Main.keyListenBind = true;
                }
            }
        });
        buttonAktywacja.setBounds(0, 290, 233, 23);
        buttonAktywacja.setFont(new Font("Segoe UI", Font.BOLD, 14));
        buttonAktywacja.setBackground(new Color(0, 0, 0));
        buttonAktywacja.setForeground(Color.WHITE);
        buttonAktywacja.setBorder(BorderFactory.createLineBorder(new Color(113, 0, 253), 3));
        buttonAktywacja.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent evt) {
				buttonAktywacja.setBackground(new Color(113, 0, 253));
			}
			
			public void mouseExited(MouseEvent evt) {
				buttonAktywacja.setBackground(new Color(0,0,0));
			}
		});
        kopanieTab.add(buttonAktywacja);
        
        textAktywacja = new JLabel("false");
        textAktywacja.setForeground(Color.RED);
        textAktywacja.setToolTipText("");
        textAktywacja.setBounds(250, 290, 40, 30);
        textAktywacja.setFont(new Font("Segoe UI", Font.BOLD, 16));
        kopanieTab.add(textAktywacja);
        
        stoniarkaSize = new JTextField();
        stoniarkaSize.setBounds(160, 52, 20, 20);
        stoniarkaSize.setColumns(10);
        stoniarkaSize.setText("10");
        stoniarkaSize.setFont(new Font("Segoe UI", Font.BOLD, 12));
        stoniarkaSize.setForeground(Color.WHITE);
        stoniarkaSize.setBackground(Color.BLACK);
        stoniarkaSize.setBorder(BorderFactory.createLineBorder(new Color(113, 0, 253), 3));
        kopanieTab.add(stoniarkaSize);
        
        stoniarkaUp = new JTextField();
        stoniarkaUp.setBounds(190, 52, 20, 20);
        stoniarkaUp.setColumns(2);
        stoniarkaUp.setText("2");
        stoniarkaUp.setFont(new Font("Segoe UI", Font.BOLD, 12));
        stoniarkaUp.setForeground(Color.WHITE);
        stoniarkaUp.setBackground(Color.BLACK);
        stoniarkaUp.setBorder(BorderFactory.createLineBorder(new Color(113, 0, 253), 3));
        kopanieTab.add(stoniarkaUp);
        
        aktywacjaRepairCommand = new JRadioButton("");
        aktywacjaRepairCommand.setBounds(160, 83, 20, 20);
        aktywacjaRepairCommand.setBackground(Color.BLACK);
        kopanieTab.add(aktywacjaRepairCommand);
        
        komenda = new JTextField();
        komenda.setColumns(10);
        komenda.setBounds(300, 83, 119, 20);
		komenda.setFont(new Font("Segoe UI", Font.BOLD, 12));
		komenda.setForeground(Color.WHITE);
		komenda.setBackground(Color.BLACK);
		komenda.setBorder(BorderFactory.createLineBorder(new Color(113, 0, 253), 3));
		komenda.setText("/repair");
        kopanieTab.add(komenda);
        
        turJedzenie = new JTextField();
        turJedzenie.setColumns(10);
        turJedzenie.setBounds(200, 238, 20, 20);
        turJedzenie.setFont(new Font("Segoe UI", Font.BOLD, 12));
        turJedzenie.setForeground(Color.WHITE);
        turJedzenie.setBackground(Color.BLACK);
		turJedzenie.setBorder(BorderFactory.createLineBorder(new Color(113, 0, 253), 3));
        kopanieTab.add(turJedzenie);
        
        turRepairKilof = new JTextField();
        turRepairKilof.setColumns(10);
        turRepairKilof.setBounds(200, 269, 20, 20);
        turRepairKilof.setFont(new Font("Segoe UI", Font.BOLD, 12));
        turRepairKilof.setForeground(Color.WHITE);
        turRepairKilof.setBackground(Color.BLACK);
        turRepairKilof.setBorder(BorderFactory.createLineBorder(new Color(113, 0, 253), 3));
        kopanieTab.add(turRepairKilof);

        radioButton_2 = new JRadioButton("");
        radioButton_2.setBounds(160, 141, 20, 20);
        radioButton_2.setBackground(Color.BLACK);
        kopanieTab.add(radioButton_2);
        
        slotJedzenie = new JTextField();
        slotJedzenie.setColumns(10);
        slotJedzenie.setBounds(300, 141, 94, 20);
        slotJedzenie.setFont(new Font("Segoe UI", Font.BOLD, 12));
        slotJedzenie.setForeground(Color.WHITE);
        slotJedzenie.setBackground(Color.BLACK);
        slotJedzenie.setBorder(BorderFactory.createLineBorder(new Color(113, 0, 253), 3));
        slotJedzenie.setText("2");
        kopanieTab.add(slotJedzenie);
        
        slotKilof = new JTextField();
        slotKilof.setColumns(10);
        slotKilof.setBounds(162, 176, 20, 20);
        slotKilof.setFont(new Font("Segoe UI", Font.BOLD, 12));
        slotKilof.setForeground(Color.WHITE);
        slotKilof.setBackground(Color.BLACK);
        slotKilof.setBorder(BorderFactory.createLineBorder(new Color(113, 0, 253), 3));
        slotKilof.setText("1");
        kopanieTab.add(slotKilof);
        
        JLabel label1 = new JLabel("Dlugosc stoniarek:");
        label1.setBounds(0, 52, 150, 20);
        label1.setFont(new Font("Segoe UI", Font.BOLD, 16));
        label1.setForeground(Color.WHITE);
        kopanieTab.add(label1);
        
        JLabel label2 = new JLabel("Naprawianie:");
        label2.setBounds(0, 83, 140, 20);
        label2.setFont(new Font("Segoe UI", Font.BOLD, 16));
        label2.setForeground(Color.WHITE);
        kopanieTab.add(label2);
        JLabel label10 = new JLabel("Komenda:");
        label10.setBounds(192, 83, 80, 20);
        label10.setFont(new Font("Segoe UI", Font.BOLD, 16));
        label10.setForeground(Color.WHITE);
        kopanieTab.add(label10);
        JLabel label6 = new JLabel("Slot kilofa:");
        label6.setBounds(0, 176, 98, 20);
        label6.setFont(new Font("Segoe UI", Font.BOLD, 16));
        label6.setForeground(Color.WHITE);
        kopanieTab.add(label6);
        JLabel label12 = new JLabel("Slot jedzenia:");
        label12.setBounds(192, 141, 120, 20);
        label12.setFont(new Font("Segoe UI", Font.BOLD, 16));
        label12.setForeground(Color.WHITE);
        kopanieTab.add(label12);
        JLabel label5 = new JLabel("Jedzenie:");
        label5.setBounds(0, 145, 140, 20);
        label5.setFont(new Font("Segoe UI", Font.BOLD, 16));
        label5.setForeground(Color.WHITE);
        kopanieTab.add(label5);
        JLabel label9 = new JLabel("Co ile tur ma naprawiac?");
        label9.setBounds(0, 269, 200, 20);
        label9.setFont(new Font("Segoe UI", Font.BOLD, 16));
        label9.setForeground(Color.WHITE);
        kopanieTab.add(label9);
        JLabel label8 = new JLabel("Co ile tur ma jesc?");
        label8.setBounds(0, 238, 188, 20);
        label8.setFont(new Font("Segoe UI", Font.BOLD, 16));
        label8.setForeground(Color.WHITE);
        kopanieTab.add(label8);
        
		dodatkiTab = new JPanel();
		JLabel dodatkiText = new JLabel("Dodatki");
		dodatkiText.setBounds(0, 10, 150, 50);
		dodatkiText.setFont(new Font("Segoe UI", Font.BOLD, 30));
		dodatkiText.setForeground(Color.WHITE);
		dodatkiTab.add(dodatkiText);
		
		JLabel niebawemText = new JLabel("Niebawem!");
		niebawemText.setBounds(0, 35, 225, 50);
		niebawemText.setFont(new Font("Segoe UI", Font.BOLD, 16));
		niebawemText.setForeground(Color.WHITE);
		dodatkiTab.add(niebawemText);
		/*                                           */
		
		opcjeTab = new JPanel();
		JLabel opcjeText = new JLabel("Opcje");
		opcjeText.setBounds(0, 10, 150, 50);
		opcjeText.setFont(new Font("Segoe UI", Font.BOLD, 30));
		opcjeText.setForeground(Color.WHITE);
		opcjeTab.add(opcjeText);
		
		JLabel slotMieczText = new JLabel("Slot miecza:");
		slotMieczText.setBounds(0, 50, 100, 25);
		slotMieczText.setForeground(Color.WHITE);
		slotMieczText.setFont(new Font("Segoe UI", Font.BOLD, 16));
		opcjeTab.add(slotMieczText);
		
		slotMiecz = new JTextField();
		slotMiecz.setBounds(0, 75, 98, 20);
		slotMiecz.setFont(new Font("Segoe UI", Font.BOLD, 16));
		slotMiecz.setForeground(Color.WHITE);
		slotMiecz.setBackground(Color.BLACK);
		slotMiecz.setBorder(BorderFactory.createLineBorder(new Color(113, 0, 253), 3));
		slotMiecz.setText("1");
		opcjeTab.add(slotMiecz);
		
		JLabel punchSlotText = new JLabel("Slot puncha:");
		punchSlotText.setBounds(0, 100, 100, 25);
		punchSlotText.setForeground(Color.WHITE);
		punchSlotText.setFont(new Font("Segoe UI", Font.BOLD, 16));
		opcjeTab.add(punchSlotText);
		
		slotPunch = new JTextField();
		slotPunch.setBounds(0, 125, 98, 20);
		slotPunch.setFont(new Font("Segoe UI", Font.BOLD, 16));
		slotPunch.setForeground(Color.WHITE);
		slotPunch.setBackground(Color.BLACK);
		slotPunch.setBorder(BorderFactory.createLineBorder(new Color(113, 0, 253), 3));
		slotPunch.setText("5");
		opcjeTab.add(slotPunch);
		
		JLabel sniezkaSlotText = new JLabel("Slot sniezki:");
		sniezkaSlotText.setBounds(0, 155, 100, 25);
		sniezkaSlotText.setForeground(Color.WHITE);
		sniezkaSlotText.setFont(new Font("Segoe UI", Font.BOLD, 16));
		opcjeTab.add(sniezkaSlotText);
		
		slotSniezka = new JTextField();
		slotSniezka.setBounds(0, 185, 98, 20);
		slotSniezka.setFont(new Font("Segoe UI", Font.BOLD, 16));
		slotSniezka.setForeground(Color.WHITE);
		slotSniezka.setBackground(Color.BLACK);
		slotSniezka.setBorder(BorderFactory.createLineBorder(new Color(113, 0, 253), 3));
		slotSniezka.setText("9");
		opcjeTab.add(slotSniezka);
		
		JLabel wedkaSlotText = new JLabel("Slot wedki:");
		wedkaSlotText.setBounds(0, 215, 100, 25);
		wedkaSlotText.setForeground(Color.WHITE);
		wedkaSlotText.setFont(new Font("Segoe UI", Font.BOLD, 16));
		opcjeTab.add(wedkaSlotText);
		
		slotWedka = new JTextField();
		slotWedka.setBounds(0, 245, 98, 20);
		slotWedka.setFont(new Font("Segoe UI", Font.BOLD, 16));
		slotWedka.setForeground(Color.WHITE);
		slotWedka.setBackground(Color.BLACK);
		slotWedka.setBorder(BorderFactory.createLineBorder(new Color(113, 0, 253), 3));
		slotWedka.setText("8");
		opcjeTab.add(slotWedka);
			
		JLabel perlaSlotText = new JLabel("Slot perly:");
		perlaSlotText.setBounds(0, 275, 100, 25);
		perlaSlotText.setForeground(Color.WHITE);
		perlaSlotText.setFont(new Font("Segoe UI", Font.BOLD, 16));
		opcjeTab.add(perlaSlotText);
		
		slotPerla = new JTextField();
		slotPerla.setBounds(0, 305, 98, 20);
		slotPerla.setFont(new Font("Segoe UI", Font.BOLD, 16));
		slotPerla.setForeground(Color.WHITE);
		slotPerla.setBackground(Color.BLACK);
		slotPerla.setBorder(BorderFactory.createLineBorder(new Color(113, 0, 253), 3));
		slotPerla.setText("4");
		opcjeTab.add(slotPerla);
		
		tabs = new JPanel();
		
		frame.setTitle("GClicker");
		frame.setSize(700, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.setVisible(true);
		frame.add(panel);
		
		panel.setLayout(null);
		tabs.setLayout(null);
		macroTab.setLayout(null);
		macroTab.setBounds(0, 0, 550, 400);
		klepaTab.setLayout(null);
		klepaTab.setBounds(0, 0, 550, 400);
		kopanieTab.setLayout(null);
		kopanieTab.setBounds(0, 0, 550, 400);
		dodatkiTab.setLayout(null);
		dodatkiTab.setBounds(0, 0, 550, 400);
		opcjeTab.setLayout(null);
		opcjeTab.setBounds(0, 0, 550, 400);
		panel.add(tabs);
		tabs.setBounds(150, 1, 550, 400);
		
		try {
			logoText = new JLabel("", new ImageIcon(new URL("https://i.imgur.com/SJLEjML.png")), SwingConstants.CENTER);
		} catch (MalformedURLException e1) {
			e1.printStackTrace();
		}
		logoText.setBounds(0, 3, 150, 50);
		logoText.setFont(new Font("Segoe UI", Font.BOLD, 24));
		logoText.setForeground(Color.WHITE);
		panel.add(logoText);
		
		macroButton = new JButton("Macro");
		macroButton.setBounds(10, 50, 125, 50);
		macroButton.setFont(new Font("Segoe UI", Font.BOLD, 24));
		macroButton.setBackground(new Color(0, 0, 0));
		macroButton.setForeground(Color.WHITE);
		macroButton.setBorder(BorderFactory.createLineBorder(new Color(113, 0, 253), 3));
		macroButton.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent evt) {
				macroButton.setBackground(new Color(113, 0, 253));
			}
			
			public void mouseExited(MouseEvent evt) {
				macroButton.setBackground(new Color(0,0,0));
			}
		});
		macroButton.addActionListener(new ClickerGui());
		panel.add(macroButton);
		
		klepaButton = new JButton("Klepa");
		klepaButton.setBounds(10, 110, 125, 50);
		klepaButton.setFont(new Font("Segoe UI", Font.BOLD, 24));
		klepaButton.setBackground(new Color(0, 0, 0));
		klepaButton.setForeground(Color.WHITE);
		klepaButton.setBorder(BorderFactory.createLineBorder(new Color(113, 0, 253), 3));
		klepaButton.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent evt) {
				klepaButton.setBackground(new Color(113, 0, 253));
			}
			
			public void mouseExited(MouseEvent evt) {
				klepaButton.setBackground(new Color(0,0,0));
			}
		});
		klepaButton.addActionListener(new ClickerGui());
		panel.add(klepaButton);
		
		kopanieButton = new JButton("Kopanie");
		kopanieButton.setBounds(10, 170, 125, 50);
		kopanieButton.setFont(new Font("Segoe UI", Font.BOLD, 22));
		kopanieButton.setBackground(new Color(0, 0, 0));
		kopanieButton.setForeground(Color.WHITE);
		kopanieButton.setBorder(BorderFactory.createLineBorder(new Color(113, 0, 253), 3));
		kopanieButton.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent evt) {
				kopanieButton.setBackground(new Color(113, 0, 253));
			}
			
			public void mouseExited(MouseEvent evt) {
				kopanieButton.setBackground(new Color(0,0,0));
			}
		});
		kopanieButton.addActionListener(new ClickerGui());
		panel.add(kopanieButton);
		
		dodatkiButton = new JButton("Dodatki");
		dodatkiButton.setBounds(10, 230, 125, 50);
		dodatkiButton.setFont(new Font("Segoe UI", Font.BOLD, 24));
		dodatkiButton.setBackground(new Color(0, 0, 0));
		dodatkiButton.setForeground(Color.WHITE);
		dodatkiButton.setBorder(BorderFactory.createLineBorder(new Color(113, 0, 253), 3));
		dodatkiButton.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent evt) {
				dodatkiButton.setBackground(new Color(113, 0, 253));
			}
			
			public void mouseExited(MouseEvent evt) {
				dodatkiButton.setBackground(new Color(0,0,0));
			}
		});
		dodatkiButton.addActionListener(new ClickerGui());
		panel.add(dodatkiButton);
		
		opcjeButton = new JButton("Opcje");
		opcjeButton.setBounds(10, 290, 125, 50);
		opcjeButton.setFont(new Font("Segoe UI", Font.BOLD, 24));
		opcjeButton.setBackground(new Color(0, 0, 0));
		opcjeButton.setForeground(Color.WHITE);
		opcjeButton.setBorder(BorderFactory.createLineBorder(new Color(113, 0, 253), 3));
		opcjeButton.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent evt) {
				opcjeButton.setBackground(new Color(113, 0, 253));
			}
			
			public void mouseExited(MouseEvent evt) {
				opcjeButton.setBackground(new Color(0,0,0));
			}
		});
		opcjeButton.addActionListener(new ClickerGui());
		panel.add(opcjeButton);
		
		frame.setIconImage(image.getImage());
		panel.setBackground(new Color(0x000000));
		tabs.setBackground(new Color(0x000000));
		macroTab.setBackground(new Color(0x000000));
		klepaTab.setBackground(new Color(0x000000));
		kopanieTab.setBackground(new Color(0x000000));
		dodatkiTab.setBackground(new Color(0x000000));
		opcjeTab.setBackground(new Color(0x000000));
				
		JLabel witamy = new JLabel("Witamy w");
		witamy.setFont(new Font("Segoe UI", Font.BOLD, 40));
		witamy.setForeground(Color.WHITE);
		witamy.setBounds(150, 50, 400, 50);
		tabs.add(witamy);
		
		JLabel gclicker_witamy = new JLabel("GClicker.PL!");
		gclicker_witamy.setFont(new Font("Segoe UI", Font.BOLD, 40));
		gclicker_witamy.setForeground(new Color(113, 0, 253));
		gclicker_witamy.setBounds(140, 100, 400, 50);
		tabs.add(gclicker_witamy);
		
		JLabel developer = new JLabel("Developer: _Kubov1337#5302");
		developer.setFont(new Font("Segoe UI", Font.BOLD, 24));
		developer.setForeground(Color.WHITE);
		developer.setBounds(10, 300, 400, 50);
		tabs.add(developer);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == macroButton) {
			tabs.removeAll();
			tabs.repaint();
			tabs.revalidate();
			
			tabs.add(macroTab);
			tabs.repaint();
			tabs.revalidate();
		}
		if(e.getSource() == klepaButton) {
			tabs.removeAll();
			tabs.repaint();
			tabs.revalidate();
			
			tabs.add(klepaTab);
			tabs.repaint();
			tabs.revalidate();
		}
		if(e.getSource() == kopanieButton) {
			tabs.removeAll();
			tabs.repaint();
			tabs.revalidate();
			
			tabs.add(kopanieTab);
			tabs.repaint();
			tabs.revalidate();
		}
		if(e.getSource() == dodatkiButton) {
			tabs.removeAll();
			tabs.repaint();
			tabs.revalidate();
			
			tabs.add(dodatkiTab);
			tabs.repaint();
			tabs.revalidate();
		}
		if(e.getSource() == opcjeButton) {
			tabs.removeAll();
			tabs.repaint();
			tabs.revalidate();
			
			tabs.add(opcjeTab);
			tabs.repaint();
			tabs.revalidate();
		}
	}
}
