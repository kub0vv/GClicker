package pl.gclicker.updater;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class NetUtil {
    public NetUtil() {
        new java.lang.Object();
    }

    public static boolean check() {
        try {
            URL website = new URL("https://gclicker.pl/");
            URLConnection connection = website.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            in.close();
            return true;
        }
        catch (IOException e) {
            return false;
        }
    }
}
