package pl.gclicker;

import java.awt.AWTException;
import java.awt.EventQueue;
import java.awt.Robot;
import java.net.URL;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JWindow;
import javax.swing.SwingConstants;

import com.github.kwhat.jnativehook.GlobalScreen;
import com.github.kwhat.jnativehook.NativeHookException;
import com.github.kwhat.jnativehook.keyboard.NativeKeyListener;
import com.github.kwhat.jnativehook.mouse.NativeMouseListener;
import com.sun.jna.Native;
import com.sun.jna.platform.win32.User32;
import com.sun.jna.platform.win32.WinDef;

import pl.gclicker.gui.LoginGui;
import pl.gclicker.listener.kopanie.KeyListenBind;
import pl.gclicker.listener.left.ClickerL;
import pl.gclicker.listener.left.KeyListenL;
import pl.gclicker.listener.left.MouseListenL;
import pl.gclicker.listener.perla.PerlaListenBind;
import pl.gclicker.listener.punch.PunchListenBind;
import pl.gclicker.listener.right.ClickerP;
import pl.gclicker.listener.right.KeyListenP;
import pl.gclicker.listener.right.MouseListenP;
import pl.gclicker.listener.sniezka.SniezkaListenBind;
import pl.gclicker.listener.wedka.WedkaListenBind;
import pl.gclicker.listener.zmianaseta.ZmianaSetaListenBind;
import pl.gclicker.updater.NetUtil;
import pl.gclicker.updater.Updater;

public class Main {	
	public static volatile /* synthetic */ MouseListenP MLP;
	public static volatile /* synthetic */ MouseListenL MLL;
    public static volatile /* synthetic */ KeyListenP KLP;
    public static volatile /* synthetic */ KeyListenL KLL;
    public static /* synthetic */ boolean keyListenP;
    public static /* ClClickerGuiClickerGuiickerGuisynthetic */ boolean keyListenL;
    public static /* synthetic */ boolean left;
    public static /* synthetic */ boolean right;
    public static /* synthetic */ int minCPS;
    public static /* synthetic */ int maxCPS;
    public static /* synthetic */ int ms;
    public static boolean Pignore;
    public static /* synthetic */ boolean keyListenBind;
    public static boolean zmianaSetaListen;
    public static boolean punchListen;
    public static boolean sniezkaListen;
    public static boolean perlaListen;
    public static boolean wedkaListen;
    public static volatile /* synthetic */ KeyListenBind KLB;
    public static volatile ZmianaSetaListenBind ZSL;
    public static volatile PunchListenBind PLB;
    public static volatile SniezkaListenBind SLB;
    public static volatile PerlaListenBind PLB2;
    public static volatile WedkaListenBind WLB;
    public static /* synthetic */ int size;
    public static int up;
    public static /* synthetic */ boolean repairCommand;
    public static /* synthetic */ String command;
    public static /* synthetic */ boolean eats;
    public static /* synthetic */ String slotEats;
    public static /* synthetic */ int slotsKilof;
    public static /* synthetic */ int turaZloto;
    public static /* synthetic */ int turaJedzenie;
    public static /* synthetic */ int turaKilof;
    
    static /* synthetic */ {
        keyListenP = false;
        keyListenL = false;
        minCPS = 9;
        maxCPS = 15;
        ms = 20;
        Pignore = false;
        keyListenBind = false;
        repairCommand = false;
        eats = false;
        zmianaSetaListen = false;
        punchListen = false;
        sniezkaListen = false;
        perlaListen = false;
        wedkaListen = false;
    }
	
	public static String VERSION = "1.2";
	
	public static boolean inMinecraft() {
        char[] buffer = new char[2048];
        WinDef.HWND hwnd = User32.INSTANCE.GetForegroundWindow();
        User32.INSTANCE.GetWindowText(hwnd, buffer, 1024);
        return Native.toString((char[])buffer).contains("Minecraft");
	}
	
    public static /* synthetic */ void main(String[] args) {
        Timer timer = new Timer();
        EventQueue.invokeLater(new Runnable(){

            @Override
            public void run() {
                try {
                	if (NetUtil.check()) {
                        System.out.println("Polaczono z internetem, sprawdzanie aktualizacji...");
                        Updater.checkVersion();
                	} else {
                        System.out.println("Brak polaczenia z internetem!!!");
                        LoginGui.start();
                    }
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        KeyListenP.toggleKeyCode = 62;
        KeyListenL.toggleKeyCode = 62;
        KeyListenBind.toggleKeyCode = 62;
        ZmianaSetaListenBind.toggleKeyCode = 62;
        PunchListenBind.toggleKeyCode = 62;
        SniezkaListenBind.toggleKeyCode = 62;
        PerlaListenBind.toggleKeyCode = 62;
        WedkaListenBind.toggleKeyCode = 62;
        Logger logger = Logger.getLogger(GlobalScreen.class.getPackage().getName());
        logger.setLevel(Level.OFF);
        logger.setUseParentHandlers(false);
        try {
            GlobalScreen.registerNativeHook();
        }
        catch (NativeHookException e) {
            JOptionPane.showMessageDialog(null, "Couldn't register the native hook.");
            System.exit(1);
        }
        KLB = new KeyListenBind();
        KLP = new KeyListenP();
        KLL = new KeyListenL();
        MLP = new MouseListenP();
        MLL = new MouseListenL();
        ZSL = new ZmianaSetaListenBind();
        PLB = new PunchListenBind();
        SLB = new SniezkaListenBind();
        PLB2 = new PerlaListenBind();
        WLB = new WedkaListenBind();
        GlobalScreen.addNativeKeyListener((NativeKeyListener)KLP);
        GlobalScreen.addNativeKeyListener((NativeKeyListener)KLL);
        GlobalScreen.addNativeMouseListener((NativeMouseListener)MLP);
        GlobalScreen.addNativeMouseListener((NativeMouseListener)MLL);
        GlobalScreen.addNativeKeyListener((NativeKeyListener)KLB);
        GlobalScreen.addNativeKeyListener((NativeKeyListener)ZSL);
        GlobalScreen.addNativeKeyListener((NativeKeyListener)PLB);
        GlobalScreen.addNativeKeyListener((NativeKeyListener)SLB);
        GlobalScreen.addNativeKeyListener((NativeKeyListener)PLB2);
        GlobalScreen.addNativeKeyListener((NativeKeyListener)WLB);
        try {
            Robot robot = new Robot();
        }
        catch (AWTException e) {
            JOptionPane.showMessageDialog(null, "AWTException thrown while instantiating Robot.");
            System.exit(1);
        }
        timer.schedule(new TimerTask(){

            @Override
            public void run() {
                ClickerP.Clicker();
            }
        }, 1000L);
        ClickerL.Clicker();
    }
}